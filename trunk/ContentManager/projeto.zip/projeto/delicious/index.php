<?php
$id_app = "j71mEo32";
$key = "dj0yJmk9eUJMM2U1VVBVa0hNJmQ9WVdrOWFqY3hiVVZ2TXpJbWNHbzlNQS0tJnM9Y29uc3VtZXJzZWNyZXQmeD0yZg--";
$secret = "fb7770c1f23596a5d4251361df1412956c93dca1";
$app_url = "http://www.guia041.com.br/delicious";

$nonce = rand(1, 14515645168);
$timestamp = time();
        
//Collect the neccesary variables and construct the API URL
$url = "https://api.login.yahoo.com/oauth/v2/get_request_token?";
$url.= "oauth_nonce=".$nonce;
$url.= "&oauth_timestamp=".$timestamp;
$url.= "&oauth_consumer_key=".$key;
$url.= "&oauth_signature_method=plaintext";
$url.= "&oauth_signature=".$secret."%26";
$url.= "&oauth_version=1.0";
$url.= "&xoauth_lang_pref=en-us";

//Make the API Call to Yahoo! 
$ch = curl_init();	
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);

//Seperate the variables received from Yahoo! and store in variables.	
$responses = explode("&", $response);
        
print_r($responses);
?>