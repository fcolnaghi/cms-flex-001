$(function(){
	$(".info_div").hide();
	
	$(".input").click(function() {$(".info_div").fadeOut('slow')});
	
	$("#loginform").submit(function(){
		$.post("admin/autentica.php", { usuario: $("#user_login").val(), senha: $("#user_pass").val() },
			function(data){
				//alert(data);
				if(data == 1) {
					document.location = 'admin/painel.php';
				}else if(data == 2) {
					$(".info_div").show().text("Usu�rio ou senha inv�lido!");
				}else if(data == 3) {
					$(".info_div").show().text("Coloque o nome do usu�rio!");
				}else if(data == 4) {
					$(".info_div").show().text("Usu�rio bloqueado!");
				}else if(data == 5) {
					$(".info_div").show().text("Coloque uma senha!");
				}				
			}
		);
		return false;
	});
});