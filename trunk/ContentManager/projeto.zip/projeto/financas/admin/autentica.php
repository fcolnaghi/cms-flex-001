<?php
	function __autoload($classe) {				
		if (!preg_match("#(DAO|HTML){1}$#", $classe, $fragment)) {
			$arquivo = "../class/".$classe."/".$classe.".class.php";
		} else {
			$diretorio = substr($classe,0,strlen($classe) - strlen($fragment[0]));
			$arquivo = "../class/".$diretorio."/".$classe.".class.php";
		}
			
		require_once $arquivo;
	}
	
	if($_POST["usuario"] == "") {
		echo 3;
		exit;
	}elseif($_POST["senha"] == "") {
		echo 5;
		exit;
	}
	
	$usuarios = new Usuarios();
	$usuariosDAO = new UsuariosDAO();
	$usuarios->setUsuario(htmlspecialchars($_POST["usuario"],ENT_QUOTES));
	$usuarios->setSenha(md5(htmlspecialchars($_POST["senha"],ENT_QUOTES)));
	
	$usuariosDAO->autenticarUsuario($usuarios);
?>