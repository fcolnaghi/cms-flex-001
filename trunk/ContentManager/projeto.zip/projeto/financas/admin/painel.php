<?php
	session_start();
	function __autoload($classe) {				
		if (!preg_match("#(DAO|HTML){1}$#", $classe, $fragment)) {
			$arquivo = "../class/".$classe."/".$classe.".class.php";
		} else {
			$diretorio = substr($classe,0,strlen($classe) - strlen($fragment[0]));
			$arquivo = "../class/".$diretorio."/".$classe.".class.php";
		}
			
		require_once $arquivo;
	}
	
	UsuariosDAO::verificaSessao();
		
	$layout = new Layout();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<?php $layout->header(); ?>
</head>
<body>
<div class="container" id="container">
    <div  id="header">
    	<?php $layout->welcome(); ?>
		<?php $layout->topo(); ?>		
    </div><!-- end header -->
	
	<div id="content" >
	    <?php $layout->menu_topo(); ?>
		<div id="content_main" class="clearfix">
			<div id="main_panel_container" class="left">
				<?php $layout->dashboard(); ?>							
				<?php $layout->shortcuts(); ?>
			</div>
			<?php $layout->menu(); ?>
		</div><!-- end #content_main -->
		
		
		
		
		
		
		
		
		<?php $layout->dialog(); ?>

		
	</div><!-- end #content -->
		   
    <?php $layout->rodape(); ?>
</div><!-- end container -->

</body>
</html>
