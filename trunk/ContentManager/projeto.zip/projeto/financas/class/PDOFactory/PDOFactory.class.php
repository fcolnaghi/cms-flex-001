<?php
class PDOFactory{
	//recebe a conex�o
	public $conexao = null;
	//qual o banco de dados
	public $dbType = "mysql";

	public $host = "dbmy0048.whservidor.com";
	public $user = "guia041_3";
	public $senha = "tekrox";
	public $db = "guia041_3";
	
	//seta a persist�ncia da conex�o
	public $persistent = false;
	
	//new PDOConnectionFactory( true ) <--- conex�o persistente
	//new PDOConnectionFactory()       <--- conexao n�o persistente
	public function PDOFactory( $persistent=false ) {
		// verifico a persist�ncia da conexao
		if($persistent != false) { $this->persistent = true; }
	}
	
	public function getConnection() {
		try {
			//realiza a conex�o
			$this->conexao = new PDO($this->dbType.":host=".$this->host.";dbname=".$this->db, $this->user, $this->senha,array( PDO::ATTR_PERSISTENT => $this->persistent ));
			$this->conexao->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

			// realizado com sucesso, retorna conectado
			return $this->conexao;
		// caso ocorra um erro, retorna o erro;
		} catch ( PDOException $ex ){
			echo $ex->getMessage();			
		}
	}
	
	// desconecta
	public function Close() {
		if($this->conexao != null)
			$this->conexao = null;
	}	

	public function __destruct() {
		$this->Close();
	}
}
?>