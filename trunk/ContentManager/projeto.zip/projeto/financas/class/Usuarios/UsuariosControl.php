<?php
	session_start();
	function __autoload($classe) {
		if (!preg_match("#(DAO|HTML|FUNC){1}$#", $classe, $fragment)) {
			$arquivo = "../".$classe."/".$classe.".class.php";
		} else {
			$diretorio = substr($classe,0,strlen($classe) - strlen($fragment[0]));
			$arquivo = "../".$diretorio."/".$classe.".class.php";
		}
		require_once $arquivo;
	}	
		
	UsuariosDAO::verificaSessao();
	
	$cadastro = new Usuarios();
	$cadastroDAO = new UsuariosDAO();
		
	if($_POST["acao"] == "add") {			
		$cadastro->setNome($_POST["nome"]);
		$cadastro->setTelefone($_POST["telefone"]);
		$cadastro->setEmail($_POST["email"]);
		$cadastro->setUsuario($_POST["usuario"]);
		$cadastro->setSenha(md5($_POST["senha"]));
		$cadastro->setStatus($_POST["status"]);		
		
		$cadastroDAO->Insere($cadastro); 
		
		$_SESSION["addusuarios_sucesso"] = 1;
		echo 1;
    }elseif($_POST["acao"] == "edit") {
    	$cadastro->setIdusuario($_POST["idusuario"]);
		$cadastro->setNome($_POST["nome"]);
		$cadastro->setTelefone($_POST["telefone"]);
		$cadastro->setEmail($_POST["email"]);
		$cadastro->setUsuario($_POST["usuario"]);
		if($_POST["senha"] != "") {
			$cadastro->setSenha(md5($_POST["senha"]));
		}		
		$cadastro->setStatus($_POST["status"]);		
		
		$cadastroDAO->Update($cadastro); 
		
		$_SESSION["editusuarios_sucesso"] = 1;
		echo 1;	
    }elseif($_GET["acao"] == "remover") {
   	 	$id = explode(",",$_GET["id"]);
		
		$totIds = count($id);
		
		for($i=0;$i<$totIds;$i++) {
			$cadastroDAO->Deleta($id[$i]);
		}
		
		$_SESSION["delusuarios_sucesso"] = 1;
		header("location: ../../admin/usuarios.php?site=listar");
    }elseif($_POST["acao"] == "editperfil") {
    	$cadastro->setIdusuario($_POST["idusuario"]);
    	$cadastro->setNome($_POST["nome"]);
    	$cadastro->setTelefone($_POST["telefone"]);
    	$cadastro->setEmail($_POST["email"]);
    	
    	if($_POST["nova"] != "") {
    		$cadastro->setSenha(md5($_POST["confirma"]));
    	}
    	
    	$cadastroDAO->Update($cadastro);
    	
   	 	$_SESSION["sucesso_perfil"] = 1;
   	 	echo 1;
    }elseif(isset($_GET["usuario"])) {
		$cadastro = $cadastroDAO->getUsuario($_GET["usuario"]);
		
		if(isset($_GET["id"])) {
			if($cadastro->getIdusuario() == $_GET["id"]) {
				echo "true";
			}else{
				echo "false";
			}
		}else{
			if($cadastro->getUsuario() == "") {
				echo "true";
			}else{
				echo "false";
			}
		}
    }elseif(isset($_GET["atual"])) {
		$cadastro = $cadastroDAO->getUsuarioPorId($_GET["id"]);
		
    	if($cadastro->getSenha() == md5($_GET["atual"])) {
			echo "true";
		}else{
			echo "false";
		}
    }
?>