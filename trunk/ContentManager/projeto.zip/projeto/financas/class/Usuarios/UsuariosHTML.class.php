<?php 
class UsuariosHTML {	
	function mostraPaginacao($paginas,$pagina,$total,$registros) { ?>		
		<?php		
		if($pagina == 0) {
			$menos = 0;
		}else{
			$menos = $pagina-1;
		} 
		
		$totMais = $paginas-1;
		
		if($pagina == $totMais) {
			$mais = $totMais;			
		}else{
			$mais = $pagina+1;
		}
		
		if(isset($_GET["pag"])) {
			$p = $_GET["pag"];
			$queryPag = str_replace("&pag=$p","",$_SERVER["QUERY_STRING"]);
		}else{
			$queryPag = $_SERVER["QUERY_STRING"];
		}
		if(isset($_GET["t"])) {
			$tot = $_GET["t"];
			$queryT = str_replace("&t=$tot","",$_SERVER["QUERY_STRING"]);
		}else{
			$queryT = $_SERVER["QUERY_STRING"];
		}
		?>
		<script type="text/javascript">
		$(document).ready(function(){
			$("#view").change(function(){
				var t = $(this).val();
				document.location = '?<?=$queryT;?>&t='+t;
			});
		});
		</script>
		<div id="pager">
        	P&aacute;gina <a href="?<?=$queryPag;?>&pag=<?=$menos;?>"><img src="../recursos_painel/imagens/arrow_left.gif" width="16" height="16" align="absmiddle" /></a>								
        	<?=$pagina+1;?> 
        	<a href="?<?=$queryPag;?>&pag=<?=$mais;?>"><img src="../recursos_painel/imagens/arrow_right.gif" width="16" height="16" align="absmiddle" /></a>de <?=$paginas;?>
        	p&aacute;ginas | Resultados <select name="view" id="view">
				        				    <option value="10" <? if($_GET["t"] == 10) { echo "selected"; } ?>>10</option>
					                        <option value="20" <? if($_GET["t"] == 20) { echo "selected"; } ?>>20</option>
					                        <option value="50" <? if($_GET["t"] == 50) { echo "selected"; }elseif(!isset($_GET["t"])) { echo "selected"; } ?>>50</option>
					                        <option value="100" <? if($_GET["t"] == 100) { echo "selected"; } ?>>100</option>
		        						</select> 
        por p&aacute;gina | Mostrando <strong><?=$total;?></strong> registros ,Total <strong><?=$registros;?></strong> registros
        </div>
	<?	}
	
	public function ListaUsuarios() {	
		$usuariosDAO = new UsuariosDAO();		
				
		$pagina = $_GET["pag"];
		if(!isset($pagina)) { $pagina = 0;}
		
		if(isset($_GET["t"])) {
			$total = $_GET["t"];
		}else{
			$total = 50;
		}
		$totalPorPagina = $total;
		$inicio = $pagina * $totalPorPagina;

		$order = "ORDER BY idusuario";
		?>			
		<div id="msg">
		<?php if(isset($_SESSION["addusuarios_sucesso"])) { ?><script type="text/javascript">$("#msg").fadeIn("slow").html("<table width='590'><tr><td class='sucesso'><span>Sucesso!</span><p>Usu�rio adicionado com sucesso!</p></td></tr></table>");</script><?php }unset($_SESSION["addusuarios_sucesso"]); ?>		
		<?php if(isset($_SESSION["editusuarios_sucesso"])) { ?><script type="text/javascript">$("#msg").fadeIn("slow").html("<table width='590'><tr><td class='sucesso'><span>Sucesso!</span><p>Usu�rio alterado com sucesso!</p></td></tr></table>");</script><?php }unset($_SESSION["editusuarios_sucesso"]); ?>		
		<?php if(isset($_SESSION["delusuarios_sucesso"])) { ?><script type="text/javascript">$("#msg").fadeIn("slow").html("<table width='590'><tr><td class='sucesso'><span>Sucesso!</span><p>Usu�rio removido com sucesso!</p></td></tr></table>");</script><?php }unset($_SESSION["delusuarios_sucesso"]); ?>					
		</div>
		<script type="text/javascript">
		setTimeout(function(){
			$("#msg").fadeOut(1000);}
		, 2000);
		</script>		
		<table class="estrutura" width="590" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td colspan="2" class="estrutura lista">
					<table width="100%" align="center">																						
						<tr>
							<th colspan="4" class="th">							
							<div class="menu_titulos">															
								<a href="?site=add">Novo Usu�rio</a>									
								<a href="javascript:history.back();">Voltar</a>									
							</div>
							Usu�rios Cadastrados
							</th>
						</tr>
						<tr>
							<td width="55%" class="h2">Nome</td>
							<td width="35%" class="h2">Usu�rio</td>																									
							<td width="10%" class="h2">A&ccedil;&otilde;es</td>
						</tr>
						<?php 
							$usuarios = $usuariosDAO->Paginacao($order,$inicio,$totalPorPagina);					
							$registros = $usuariosDAO->Registros($order);
							
							$paginas = ceil($registros / $totalPorPagina);
							
							$totUsuarios = count($usuarios);
						?>
						<?
						if($usuarios) { 
							for($i=0;$i<$totUsuarios;$i++) { ?>
						<tr>
							<td class="td" style="cursor:pointer;" onclick="javascript:document.location = 'usuarios.php?site=edit&edit=<?=$usuarios[$i]->getIdusuario();?>'"><?=$usuarios[$i]->getNome();?></td>
							<td class="td" style="cursor:pointer;" onclick="javascript:document.location = 'usuarios.php?site=edit&edit=<?=$usuarios[$i]->getIdusuario();?>'"><?=$usuarios[$i]->getUsuario();?></td>																																	
							<td class="td">	
								<a href="usuarios.php?site=edit&edit=<?=$usuarios[$i]->getIdusuario();?>"><img src="../recursos_painel/css/v1/edit.png" alt="edit.png" title="Editar"/></a>
								<a href="../class/Usuarios/UsuariosControl.php?acao=remover&id=<?=$usuarios[$i]->getIdusuario();?>" onclick="return confirm('Deseja realmente excluir o usu�rio: <?=$usuarios[$i]->getNome();?>');"><img src="../recursos_painel/css/v1/deletar.png" alt="deletar.png" title="Deletar"/></a>						
							</td>							
						</tr>
						<? 
							}
						}else{ ?>
							<tr>
		                       	<td align="center" colspan="4" class="td2">N�o h� resultados</td>                       	
		                    </tr>
					 <? } ?>						 					
					</table>
					<?php if($usuarios) { $this->mostraPaginacao($paginas,$pagina,$totUsuarios,$registros); }?>					
				</td>
			</tr>			
		</table>				
		<?
	}
	
	function AddCadastro() {			
		?>			
		<form id="addusuarios" name="addusuarios" method="post" class="marca">    
		<input name="acao" id="acao" type="hidden" value="add"/>     
		<table class="estrutura" width="590" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td colspan="2" class="estrutura td">
					<table width="100%" align="center">
						<tr>
							<th class="th" colspan="6">								
								<div class="menu_titulos">
									<a href="usuarios.php?site=listar">Voltar</a>
								</div>
								Adicionar Usu&aacute;rio																
							</th>							
						</tr>											
						<tr>
							<td class="td">Nome:</td>
							<td class="td" colspan="6"><input name="nome" id="nome" type="text" size="94" class="required" /></td>
						</tr>
						<tr>
							<td class="td">Telefone:</td>
							<td class="td"><input name="telefone" id="telefone" type="text" size="15" class="required" /></td>							
							<td class="td">E-Mail:</td>
							<td class="td" colspan="6"><input name="email" id="email" type="text" size="56" class="email required" /></td>
						</tr>						
						<tr>
							<td class="td">Usu&aacute;rio:</td>
							<td class="td"><input name="usuario" id="usuario" type="text" size="15" class="required" /></td>
							<td class="td">Senha:</td>
							<td class="td"><input name="senha" id="senha" type="password" size="15" class="required" /></td>
							<td class="td">Status:</td>
							<td class="td">
								<select name="status" id="status" class="required">	               	
									<option value="">--Selecione--</option>	                 										  				
									<option value="1">Ativo</option>	                 										  				
									<option value="0">Inativo</option>	                 										  				
								</select>
							</td>
						</tr>																					
						<tr>
							<td class="td2" colspan="6"><input type="submit" id="btnEnviar_usuarios" value="Adicionar" title="Adicionar" class="botao"/></td>							
						</tr>																							
					</table>					
				</td>
			</tr>
		</table>
		</form>	
		<div class="container">
			<p>Os campos em destaque s&atilde;o obrigat&oacute;rios !</p>
			<ol>
				<li><label for="controle" class="error">Selecione um controle.</label></li>				
				<li><label for="nome" class="error">Coloque seu nome.</label></li>	
				<li><label for="telefone" class="error">Coloque seu telefone.</label></li>																																										
				<li><label for="status" class="error">Selecione o status.</label></li>											
			</ol>
		</div>	
		<?		
	}
	
	function EditCadastro() {
		$edit = $_GET["edit"];			

		$cadastroDAO = new UsuariosDAO();
		$cadastro = $cadastroDAO->getUsuarioPorId($edit); 		
		?>	
		<form id="editusuarios" name="editusuarios" method="post" class="marca">    
		<input name="acao" id="acao" type="hidden" value="edit"/>     
		<input name="idusuario" id="idusuario" type="hidden" value="<?=$edit;?>"/>     
		<table class="estrutura" width="590" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td colspan="2" class="estrutura td">
					<table width="100%" align="center">
						<tr>
							<th class="th" colspan="6">								
								<div class="menu_titulos">
									<a href="usuarios.php?site=listar">Voltar</a>
								</div>
								Editar Usu&aacute;rio																
							</th>							
						</tr>											
						<tr>
							<td class="td">Nome:</td>
							<td class="td" colspan="6"><input name="nome" id="nome" type="text" size="94" class="required" value="<?=$cadastro->getNome();?>" /></td>
						</tr>
						<tr>
							<td class="td">Telefone:</td>
							<td class="td"><input name="telefone" id="telefone" type="text" size="15" class="required" value="<?=$cadastro->getTelefone();?>" /></td>							
							<td class="td">E-Mail:</td>
							<td class="td" colspan="6"><input name="email" id="email" type="text" size="56" class="email required" value="<?=$cadastro->getEmail();?>" /></td>
						</tr>						
						<tr>
							<td class="td">Usu&aacute;rio:</td>
							<td class="td"><input name="usuario" id="usuario" type="text" size="15" class="required" value="<?=$cadastro->getUsuario();?>" /></td>
							<td class="td">Senha:</td>
							<td class="td"><input name="senha" id="senha" type="password" size="15" /></td>
							<td class="td">Status:</td>
							<td class="td">
								<select name="status" id="status" class="required">	               	
									<option value="">--Selecione--</option>	                 										  				
									<option value="1" <? if($cadastro->getStatus() == 1) { echo "selected"; } ?>>Ativo</option>	                 										  				
									<option value="0" <? if($cadastro->getStatus() == 0) { echo "selected"; } ?>>Inativo</option>	                 										  				
								</select>
							</td>
						</tr>																					
						<tr>
							<td class="td2" colspan="6"><input type="submit" id="btnEnviar_usuarios" value="Salvar" title="Salvar" class="botao"/></td>							
						</tr>																							
					</table>					
				</td>
			</tr>
		</table>
		</form>	
		<div class="container">
			<p>Os campos em destaque s&atilde;o obrigat&oacute;rios !</p>
			<ol>
				<li><label for="controle" class="error">Selecione um controle.</label></li>				
				<li><label for="nome" class="error">Coloque seu nome.</label></li>	
				<li><label for="telefone" class="error">Coloque seu telefone.</label></li>																																										
				<li><label for="status" class="error">Selecione o status.</label></li>											
			</ol>
		</div>	
		<?		
	}
	
	function EditMeuPerfil() {
		$edit = $_SESSION["idusuario_logado"];
		
		$cadastroDAO = new UsuariosDAO();
		$cadastro = $cadastroDAO->getUsuarioPorId($edit); 
		
		?>	
		<div id="msg">
		<?php if(isset($_SESSION["sucesso_perfil"])) { ?><script type="text/javascript">$("#msg").fadeIn("slow").html("<table width='590'><tr><td class='sucesso'><span>Sucesso!</span><p>Perfil alterado com sucesso!</p></td></tr></table>");</script><?php }unset($_SESSION["sucesso_perfil"]); ?>		
		</div>
		<script type="text/javascript">
		setTimeout(function(){
			$("#msg").fadeOut(1000);}
		, 2000);
		</script>		
		<form id="editmeuperfil" name="editmeuperfil" method="post" class="marca validacao">    
		<input name="acao" id="acao" type="hidden" value="editperfil"/>     
		<input name="idusuario" id="idusuario" type="hidden" value="<?=$edit;?>"/>     
		<table class="estrutura" width="590" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td colspan="2" class="estrutura td">
					<table width="100%" align="center">
						<tr>
							<th class="th" colspan="6">																
								Editar Meus Dados																
							</th>							
						</tr>											
						<tr>
							<td class="td">Nome:</td>
							<td class="td" colspan="6"><input name="nome" id="nome" type="text" size="94" value="<?=$cadastro->getNome();?>" class="required" /></td>
						</tr>
						<tr>
							<td class="td">Telefone:</td>
							<td class="td"><input name="telefone" id="telefone" type="text" size="15" value="<?=$cadastro->getTelefone();?>" class="required" /></td>							
							<td class="td">E-Mail:</td>
							<td class="td" colspan="6"><input name="email" id="email" type="text" size="56" value="<?=$cadastro->getEmail();?>" class="email required" /></td>
						</tr>
						<tr>
							<td class="td" colspan="6"><b>Para alterar sua senha preencha os campos abaixo, caso contrario, n�o coloque nada.</b></td>							
						</tr>						
						<tr>
							<td class="td">Atual:</td>
							<td class="td"><input name="atual" id="atual" type="password" size="15" value=""/></td>
							<td class="td">Nova:</td>
							<td class="td"><input name="nova" id="nova" type="password" size="15" value=""/></td>
							<td class="td">Confirma:</td>
							<td class="td"><input name="confirma" id="confirma" type="password" size="15" value=""/></td>							
						</tr>																		
						<tr>
							<td class="td2" colspan="6"><input type="submit" id="btnEnviar" value="Salvar" title="Salvar" class="botao" /></td>							
						</tr>																			
					</table>					
				</td>
			</tr>
		</table>
		</form>	
		<div class="container">
			<p>Os campos em destaque s&atilde;o obrigat&oacute;rios !</p>
			<ol>
				<li><label for="nome" class="error">Coloque seu nome.</label></li>				
				<li><label for="email" class="error">Coloque seu e-mail.</label></li>				
				<li><label for="telefone" class="error">Coloque seu telefone.</label></li>				
			</ol>
		</div>					
		<?		
	}
}
?>
