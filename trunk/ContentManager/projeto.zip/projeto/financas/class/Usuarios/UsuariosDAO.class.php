<?
/**
 * Classe respons�vel pelas Consultas de usu�rio no BD
 * 
 * Criado por: Erinthon Colnaghi Ribeiro
 * Data Cria��o: 03/04/2009
 *
 */

class UsuariosDAO extends PDOFactory {
	
	public $conexao = null;
	
	/**
	 * Metodo respons�vel por capturar a conex�o gerada pelo PDO
	 *
	 * @return UsuariosDAO
	 */
	public function UsuariosDAO() {
		$this->conexao = PDOFactory::getConnection();
	}
	
	public function ListaUsuarios($option = "") {
		try {
			$sql = "SELECT idusuario,nome,usuario FROM usuarios $option";
			$stmt = $this->conexao->prepare($sql);	
			$stmt->execute();
			
			$searchResults = array();
			
			while ($rs = $stmt->fetch(PDO::FETCH_OBJ)) {
				$temp = new Usuarios();
				
				$temp->setIdusuario($rs->idusuario);
				$temp->setNome($rs->nome);													
				$temp->setUsuario($rs->usuario);																									
				
				array_push($searchResults, $temp);
			} 
			
			return $searchResults;
			
		} catch (PDOException $e) {
			header("Content-Type: text/html; charset=ISO-8859-1");
			echo "<div id=\"erro\" style=\"font-size: 12px; color: red\">";
			echo "	<h3>Erro ao fazer a consulta:</h3>";
			echo "	<ul>";
			echo "		<li>Erro: ".$e->getMessage()."</li>";
			echo "		<li>Linha: ".$e->getLine()."</li>";
			echo "		<li>Arquivo: ".$e->getFile()."</li>";
			echo "	</ul>";
			echo "</div>";
		}
	}
	
	/**
	 * Insere um novo usuario no banco de dados.
	 *
	 * @param objeto $administracao
	 */
	public function Insere( $cadastro ){
		try {
			$sql = "INSERT INTO usuarios (nome,email,telefone,usuario,senha,status) VALUES (?,?,?,?,?,?)";
			$stmt = $this->conexao->prepare($sql);
			
			// sequencia de �ndices que representa cada valor de minha query
			$stmt->bindValue(1, $cadastro->getNome());		
			$stmt->bindValue(2, $cadastro->getEmail());
			$stmt->bindValue(3, $cadastro->getTelefone());
			$stmt->bindValue(4, $cadastro->getUsuario());
			$stmt->bindValue(5, $cadastro->getSenha());
			$stmt->bindValue(6, $cadastro->getStatus());
						
			// executo a query preparada
			$stmt->execute();								
		} catch (PDOException $e) {
			echo $e->getMessage();
		}		
	}	
	
	/**
	 * Altera um usuario no banco de dados
	 *
	 * @param objeto $object
	 */
	public function Update($object) {
    	try {
    		$i = 0;
    		foreach ($object as $key => $value) {
    			if($i != 0) $v = ",";
    			if($value != "" && $key != "idusuario") {
    				$valores .= $v.$key."= ?";
    				$i++;
    			}
    		}
    		    		
    		$sql = "UPDATE usuarios SET ".$valores." WHERE (idusuario = ?) LIMIT 1;";
    		
     		$stmt = $this->conexao->prepare($sql);
		
     		$i=1;
     		foreach ($object as $key => $value) {
    			if($value != "" && $key != "idusuario") {    				
					$classe = "get".$key;
					$stmt->bindValue($i, $object->$classe());
					$i++;
    			}
    		}
     		
    		$stmt->bindValue($i, $object->getIdusuario());
			
			$stmt->execute();			
			
    	} catch (PDOException $e) {
			echo $e->getMessage();
		}
    }	
	
	public function autenticarUsuario($usuarios) {
		try {
			$sql = "SELECT * from usuarios WHERE usuario = '".$usuarios->getUsuario()."' and senha = '".$usuarios->getSenha()."' Limit 1";

			$stmt = $this->conexao->prepare($sql);
			
			$stmt->execute();
			$searchResults = array();
						
			if($rs = $stmt->fetch(PDO::FETCH_OBJ)) {			
				if($rs->status == 1) {				
					session_start();
					$_SESSION['idusuario_logado'] = $rs->idusuario;
					$_SESSION['nome_logado'] = $rs->nome;
					
					$logs = new Logs();
					$logsDAO = new LogsDAO();
					
					$logs->setIdusuario($rs->idusuario);					
					$logs->setUsuario($rs->nome);				
					$logs->setData(date("y-m-d H:i:s"));				
					$logs->setIp($_SERVER["REMOTE_ADDR"]);	
					
					$logsDAO->Insere($logs);
								
					echo 1;												
				} else {
					echo 4;															
				}
			}else{
				echo 2;				
			}
			
		} catch (PDOException $e) {
			echo $e->getMessage();
		}
	}
	
	public static function verificaSessao() {		
		if (!isset($_SESSION["idusuario_logado"])) {
			//$_SESSION['erro'] = "Sua sess�o expirou, ou o seu usu�rio esta inv�lido";
			header("Location: index.php");
		} 
	}
	
	public function getUsuarioPorId($idusuario) {
		try {
			$sql = "SELECT * FROM usuarios WHERE idusuario = ?";
			$stmt = $this->conexao->prepare($sql);
			$stmt->bindValue(1,$idusuario);
			
			$stmt->execute();
			
			$searchResults = array();
			
			$rs = $stmt->fetch(PDO::FETCH_OBJ);
			
			$temp = new Usuarios();
			
			$temp->setIdusuario($rs->idusuario);				
			$temp->setNome($rs->nome);				
			$temp->setEmail($rs->email);				
			$temp->setTelefone($rs->telefone);				
			$temp->setUsuario($rs->usuario);				
			$temp->setSenha($rs->senha);									
			$temp->setStatus($rs->status);
				
			return $temp;
		} catch (PDOException $e) {
			header("Content-Type: text/html; charset=ISO-8859-1");
			echo "<div id=\"erro\" style=\"font-size: 12px; color: red\">";
			echo "	<h3>Erro ao fazer a consulta:</h3>";
			echo "	<ul>";
			echo "		<li>Erro: ".$e->getMessage()."</li>";
			echo "		<li>Linha: ".$e->getLine()."</li>";
			echo "		<li>Arquivo: ".$e->getFile()."</li>";
			echo "	</ul>";
			echo "</div>";
		}			
	}
	
	public function getUsuario($usuario) {
		try {
			$sql = "SELECT * FROM usuarios WHERE usuario = ?";
			$stmt = $this->conexao->prepare($sql);
			$stmt->bindValue(1,$usuario);
			
			$stmt->execute();
			
			$searchResults = array();
			
			$rs = $stmt->fetch(PDO::FETCH_OBJ);
			
			$temp = new Usuarios();
							
			$temp->setIdusuario($rs->idusuario);					
			$temp->setUsuario($rs->usuario);							
				
			return $temp;
		} catch (PDOException $e) {
			header("Content-Type: text/html; charset=ISO-8859-1");
			echo "<div id=\"erro\" style=\"font-size: 12px; color: red\">";
			echo "	<h3>Erro ao fazer a consulta:</h3>";
			echo "	<ul>";
			echo "		<li>Erro: ".$e->getMessage()."</li>";
			echo "		<li>Linha: ".$e->getLine()."</li>";
			echo "		<li>Arquivo: ".$e->getFile()."</li>";
			echo "	</ul>";
			echo "</div>";
		}			
	}
	
	public function Paginacao($order="",$inicio,$fim) {
		try {
			$sql = "SELECT * FROM usuarios $order LIMIT $inicio,$fim";
			$stmt = $this->conexao->prepare($sql);	
			
			$stmt->execute();
			$searchResults = array();
			
			while ($rs = $stmt->fetch(PDO::FETCH_OBJ)) {
				$temp = new Usuarios();
				$temp->setIdusuario($rs->idusuario);
				$temp->setNome($rs->nome);													
				$temp->setUsuario($rs->usuario);																		
				
				array_push($searchResults, $temp);
			} 
			
			return $searchResults;
		} catch (PDOException $e) {
			header("Content-Type: text/html; charset=ISO-8859-1");
			echo "<div id=\"erro\" style=\"font-size: 12px; color: red\">";
			echo "	<h3>Erro ao fazer a consulta:</h3>";
			echo "	<ul>";
			echo "		<li>Erro: ".$e->getMessage()."</li>";
			echo "		<li>Linha: ".$e->getLine()."</li>";
			echo "		<li>Arquivo: ".$e->getFile()."</li>";
			echo "	</ul>";
			echo "</div>";
		}	
	}
	
	public function Registros($order="") {
		$sql = "SELECT * FROM usuarios $order";
		$stmt = $this->conexao->prepare($sql);	
		
		$stmt->execute();
		$searchResults = array();
		
		$registros = $stmt->rowCount(PDO::FETCH_OBJ);
		
		return $registros;
	}
	
	public function Deleta( $id ) {
		try {
			$sql = "DELETE FROM usuarios WHERE idusuario = ?";
			$stmt = $this->conexao->prepare($sql);
			$stmt->bindValue(1,$id);
			
			$stmt->execute();
			
			$error = $stmt->errorInfo();
		} catch (PDOException $e) {
			header("Content-Type: text/html; charset=ISO-8859-1");
			echo "<div id=\"erro\" style=\"font-size: 12px; color: red\">";
			echo "	<h3>Erro ao fazer a consulta:</h3>";
			echo "	<ul>";
			echo "		<li>Erro: ".$e->getMessage()."</li>";
			echo "		<li>Linha: ".$e->getLine()."</li>";
			echo "		<li>Arquivo: ".$e->getFile()."</li>";
			echo "	</ul>";
			echo "</div>";
		}
	}
}
?>