<?php
class Logs {
	public $idlog;
	public $idusuario;
	public $usuario;
	public $data;
	public $ip;
	
	public function getData() {
		return $this->data;
	}
	
	public function getIdlog() {
		return $this->idlog;
	}
	
	public function getIdusuario() {
		return $this->idusuario;
	}
	
	public function getIp() {
		return $this->ip;
	}
	
	public function getUsuario() {
		return $this->usuario;
	}
	
	public function setData($data) {
		$this->data = $data;
	}
	
	public function setIdlog($idlog) {
		$this->idlog = $idlog;
	}
	
	public function setIdusuario($idusuario) {
		$this->idusuario = $idusuario;
	}
	
	public function setIp($ip) {
		$this->ip = $ip;
	}
	
	public function setUsuario($usuario) {
		$this->usuario = $usuario;
	}
}
?>