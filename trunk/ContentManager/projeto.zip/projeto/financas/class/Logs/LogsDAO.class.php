<?php
class LogsDAO extends PDOFactory {
	public $conexao = null;
	
	public function LogsDAO() {
		$this->conexao = PDOFactory::getConnection();
	}
	
	public function Insere( $logs ){
		try {
			$sql = "INSERT INTO logs (idusuario,usuario,data,ip) VALUES (?,?,?,?)";
			$stmt = $this->conexao->prepare($sql);
			
			// sequencia de �ndices que representa cada valor de minha query
			$stmt->bindValue(1, $logs->getIdusuario());					
			$stmt->bindValue(2, $logs->getUsuario());					
			$stmt->bindValue(3, $logs->getData());					
			$stmt->bindValue(4, $logs->getIp());					
						
			// executo a query preparada
			$stmt->execute();								
		} catch (PDOException $e) {
			header("Content-Type: text/html; charset=ISO-8859-1");
			echo "<div id=\"erro\" style=\"font-size: 12px; color: red\">";
			echo "	<h3>Erro ao fazer a consulta:</h3>";
			echo "	<ul>";
			echo "		<li>Erro: ".$e->getMessage()."</li>";
			echo "		<li>Linha: ".$e->getLine()."</li>";
			echo "		<li>Arquivo: ".$e->getFile()."</li>";
			echo "	</ul>";
			echo "</div>";
		}		
	}
	
	public function getUltimaVisita($option = "") {
		try {
			$sql = "SELECT * FROM logs $option";
			$stmt = $this->conexao->prepare($sql);	
			$stmt->execute();
						
			while ($rs = $stmt->fetch(PDO::FETCH_OBJ)) {
				$temp = new Logs();
				
				$temp->setIdlog($rs->idlog);																																																																									
				$temp->setIdusuario($rs->idusuario);																																																																									
				$temp->setUsuario($rs->usuario);																																																																									
				$temp->setData($rs->data);																																																																									
				$temp->setIp($rs->ip);																																																																																
			} 
			
			return $temp;
			
		} catch (PDOException $e) {
			header("Content-Type: text/html; charset=ISO-8859-1");
			echo "<div id=\"erro\" style=\"font-size: 12px; color: red\">";
			echo "	<h3>Erro ao fazer a consulta:</h3>";
			echo "	<ul>";
			echo "		<li>Erro: ".$e->getMessage()."</li>";
			echo "		<li>Linha: ".$e->getLine()."</li>";
			echo "		<li>Arquivo: ".$e->getFile()."</li>";
			echo "	</ul>";
			echo "</div>";
		}
	}
}
?>