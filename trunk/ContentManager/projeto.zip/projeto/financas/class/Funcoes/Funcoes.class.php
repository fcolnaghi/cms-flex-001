<?php
class Funcoes {	
	function mostraMoney($valor) {
		$valor = explode(",",$valor);
		$valor = $valor[0].".".$valor[1];
		$valor = floatval($valor);
		
		$valor = number_format($valor,2,",",".");
		return $valor;
	}
	
	function rand_str($length = 32, $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890')
	{
	    // Length of character list
	    $chars_length = (strlen($chars) - 1);
	
	    // Start our string
	    $string = $chars{rand(0, $chars_length)};
	   
	    // Generate random string
	    for ($i = 1; $i < $length; $i = strlen($string))
	    {
	        // Grab a random character from our list
	        $r = $chars{rand(0, $chars_length)};
	       
	        // Make sure the same two characters don't appear next to each other
	        if ($r != $string{$i - 1}) $string .=  $r;
	    }
	   
	    // Return the string
	    return $string;
	}
	
	function generateRandStr($length){
      $randstr = "";
      for($i=0; $i<$length; $i++){
         $randnum = mt_rand(0,61);
         if($randnum < 10){
            $randstr .= chr($randnum+48);
         }else if($randnum < 36){
            $randstr .= chr($randnum+55);
         }else{
            $randstr .= chr($randnum+61);
         }
      }
      return $randstr;
   } 
	
	public function EmailValido($email)
	{
	    if (ereg("^[_a-zA-Z0-9-]+(\.[_a-zA-Z0-9-]+)*@([_a-zA-Z0-9-]+\.)*[a-zA-Z0-9-]{2,200}\.[a-zA-Z]{2,6}$", $email ) )
		{
	       return true;
	    }
		else
		{
	       return false;
	    }
	}
	
	public function remove_acentos($texto) {
		$texto = str_replace("�","a",$texto);
		$texto = str_replace("�","e",$texto);
		$texto = str_replace("�","i",$texto);
		$texto = str_replace("�","o",$texto);
		$texto = str_replace("�","u",$texto);
		
		$texto = str_replace("�","A",$texto);
		$texto = str_replace("�","E",$texto);
		$texto = str_replace("�","I",$texto);
		$texto = str_replace("�","O",$texto);
		$texto = str_replace("�","U",$texto);
		
		$texto = str_replace("�","a",$texto);
		$texto = str_replace("�","e",$texto);
		$texto = str_replace("�","i",$texto);
		$texto = str_replace("�","o",$texto);
		$texto = str_replace("�","u",$texto);
		
		$texto = str_replace("�","A",$texto);
		$texto = str_replace("�","E",$texto);
		$texto = str_replace("�","I",$texto);
		$texto = str_replace("�","O",$texto);
		$texto = str_replace("�","U",$texto);
		
		$texto = str_replace("�","a",$texto);
		$texto = str_replace("�","A",$texto);
		$texto = str_replace("�","o",$texto);
		$texto = str_replace("�","O",$texto);
		
		$texto = str_replace("�","a",$texto);
		$texto = str_replace("�","A",$texto);
		$texto = str_replace("�","o",$texto);
		$texto = str_replace("�","O",$texto);
		$texto = str_replace("�","e",$texto);
		$texto = str_replace("�","E",$texto);
		
		$texto = str_replace("�","c",$texto);
		$texto = str_replace("�","C",$texto);
		
		return $texto;		
	}
	
	public function troca_acentos($texto,$valor) {
		$texto = str_replace("&aacute;","�",$texto);
		$texto = str_replace("&eacute;","�",$texto);
		$texto = str_replace("&iacute;","�",$texto);
		$texto = str_replace("&oacute;","�",$texto);
		$texto = str_replace("&uacute;","�",$texto);
		
		$texto = str_replace("&Aacute;","�",$texto);
		$texto = str_replace("&Eacute;","�",$texto);
		$texto = str_replace("&Iacute;","�",$texto);
		$texto = str_replace("&Oacute;","�",$texto);
		$texto = str_replace("&Uacute;","�",$texto);
		
		$texto = str_replace("&agrave;","�",$texto);
		$texto = str_replace("&egrave;","�",$texto);
		$texto = str_replace("&igrave;","�",$texto);
		$texto = str_replace("&ograve;","�",$texto);
		$texto = str_replace("&ugrave;","�",$texto);
		
		$texto = str_replace("&Agrave;","�",$texto);
		$texto = str_replace("&Egrave;","�",$texto);
		$texto = str_replace("&Igrave;","�",$texto);
		$texto = str_replace("&Ograve;","�",$texto);
		$texto = str_replace("&Ugrave;","�",$texto);
		
		$texto = str_replace("&atilde;","�",$texto);
		$texto = str_replace("&Atilde;","�",$texto);
		$texto = str_replace("&otilde;","�",$texto);
		$texto = str_replace("&Otilde;","�",$texto);
		
		$texto = str_replace("&acirc;","�",$texto);
		$texto = str_replace("&Acirc;","�",$texto);
		$texto = str_replace("&ocirc;","�",$texto);
		$texto = str_replace("&Ocirc;","�",$texto);
		$texto = str_replace("&ecirc;","�",$texto);
		$texto = str_replace("&Ecirc;","�",$texto);
		
		$texto = str_replace("&ccedil;","�",$texto);
		$texto = str_replace("&Ccedil;","�",$texto);
		
		if(strlen($texto) < $valor) {
			echo $texto;
		}else{
			echo substr($texto,0,$valor)."...";
		}
	}
	
	public function troca_acentos_semlimite($texto) {
		$texto = str_replace("&aacute;","�",$texto);
		$texto = str_replace("&eacute;","�",$texto);
		$texto = str_replace("&iacute;","�",$texto);
		$texto = str_replace("&oacute;","�",$texto);
		$texto = str_replace("&uacute;","�",$texto);
		
		$texto = str_replace("&Aacute;","�",$texto);
		$texto = str_replace("&Eacute;","�",$texto);
		$texto = str_replace("&Iacute;","�",$texto);
		$texto = str_replace("&Oacute;","�",$texto);
		$texto = str_replace("&Uacute;","�",$texto);
		
		$texto = str_replace("&agrave;","�",$texto);
		$texto = str_replace("&egrave;","�",$texto);
		$texto = str_replace("&igrave;","�",$texto);
		$texto = str_replace("&ograve;","�",$texto);
		$texto = str_replace("&ugrave;","�",$texto);
		
		$texto = str_replace("&Agrave;","�",$texto);
		$texto = str_replace("&Egrave;","�",$texto);
		$texto = str_replace("&Igrave;","�",$texto);
		$texto = str_replace("&Ograve;","�",$texto);
		$texto = str_replace("&Ugrave;","�",$texto);
		
		$texto = str_replace("&atilde;","�",$texto);
		$texto = str_replace("&Atilde;","�",$texto);
		$texto = str_replace("&otilde;","�",$texto);
		$texto = str_replace("&Otilde;","�",$texto);
		
		$texto = str_replace("&acirc;","�",$texto);
		$texto = str_replace("&Acirc;","�",$texto);
		$texto = str_replace("&ocirc;","�",$texto);
		$texto = str_replace("&Ocirc;","�",$texto);
		$texto = str_replace("&ecirc;","�",$texto);
		$texto = str_replace("&Ecirc;","�",$texto);
		
		$texto = str_replace("&ccedil;","�",$texto);
		$texto = str_replace("&Ccedil;","�",$texto);
		
		return $texto;
	}
	
	function MostraDataNoticiaInterna($data) {
		$data = explode("-",$data);
		
		$data = $data[2];
		
		return $data;
	}
	
	function MostraDataAgendaInterna($data) {
		$data = explode("-",$data);
		
		$data = $data[2]." ".substr($this->MostraMesExtensoPorMes($data[1]),0,3)." ".substr($data[0],2,2);
		
		return $data;
	}
	
	
	function MostraDataNoticiaHome($data) {
		$data = explode("-",$data);
		
		$data = $data[2].".".$data[1];
		
		return $data;
	}
	
	function MostraMesExtenso($data) {
		if($data) {
			$data = explode("-",$data);
			switch ($data[1]) {
				case 1: $mes = "Janeiro"; break;
				case 2: $mes = "Fevereiro"; break;
				case 3: $mes = "Mar�o"; break;
				case 4: $mes = "Abril"; break;
				case 5: $mes = "Maio"; break;
				case 6: $mes = "Junho"; break;
				case 7: $mes = "Julho"; break;
				case 8: $mes = "Agosto"; break;
				case 9: $mes = "Setembro"; break;
			  case  10: $mes = "Outubro"; break;
			  case  11: $mes = "Novembro"; break;
			  case  12: $mes = "Dezembro"; break;					
			}
			$data = $mes;
		}
		
		return $data;
	}
	
	function MostraMesExtensoPorMes($mes) {
		if($mes) {			
			switch ($mes) {
				case 01: $mes = "Janeiro"; break;
				case 02: $mes = "Fevereiro"; break;
				case 03: $mes = "Mar�o"; break;
				case 04: $mes = "Abril"; break;
				case 05: $mes = "Maio"; break;
				case 06: $mes = "Junho"; break;
				case 07: $mes = "Julho"; break;
				case 08: $mes = "Agosto"; break;
				case 09: $mes = "Setembro"; break;
				case  10: $mes = "Outubro"; break;
				case  11: $mes = "Novembro"; break;
				case  12: $mes = "Dezembro"; break;					
			}			
		}
		
		return $mes;
	}
	
	public function limitaTexto($completo,$valor) {
		if(strlen($completo) < $valor) {
			echo $completo;
		}else{
			echo substr($completo,0,$valor)."...";
		}
	}
	
	public function MostraAno($data) {
		$data = explode("-",$data);
		$hora = explode(" ",$data[2]);
		
		$data = $data[0];
		
		return $data;
		
	}	
	
	public function FormataData($data) {
		$data = explode("/",$data);
		$data = $data[2]."-".$data[1]."-".$data[0];
		
		return $data;
	}
	
	public function MostraData($data) {
		$data = explode("-",$data);
		$hora = explode(" ",$data[2]);
		
		$data = $hora[0]."/".$data[1]."/".$data[0];
		
		return $data." ".$hora[1];
		
	}
	
	public function MostraDataSemHora($data) {
		$data = explode("-",$data);
		$hora = explode(" ",$data[2]);
		
		$data = $hora[0]."/".$data[1]."/".$data[0];
		
		return $data;
		
	}
	
	public function MostraHoraSemData($data) {
		$data = explode("-",$data);
		$hora = explode(" ",$data[2]);
		
		//$data = $hora[0]."/".$data[1]."/".$data[0];
		
		return $hora[1];
		
	}
	
	public function MostraMes($data) {
		$data = explode("/",$data);			
		
		return $data[1];
		
	}
	
	function thumbMaker($imagem, $aprox, $mini,$diretorio)
	{
	    if (!file_exists($imagem))
	    {
	        
	    	echo "<center><h3>Imagem n�o encontrada.</h3></center>";
	        return false;
	    }
	
	    // verifica se est� executando sob windows ou unix-like, para a
	    // aplica��o do separador de diret�rios correto.
	    if (strtoupper(substr(PHP_OS, 0,3) == 'WIN'))
	       $barra= "\\";
	    else
	       $barra= "/";
	
	    // obt�m a extens�o pelo mime-type
	    $ext = $this->getExt($imagem);
	    if (!$ext)
	    {
	       echo "<center><h3>Tipo inv�lido</h3></center>";
	       return false;
	    }
	    // separa o nome do arquivo do(s) diret�rio(s)
	    $dir_arq= explode($barra, $imagem);
	      
	    // monta o nome do arquivo a ser gerado (thumbnail). O sizeof abaixo obt�m o n�mero de itens
	    // no array, dessa forma podemos pegar somente o nome do arquivo, n�o importando em que
	    // diret�rio est�.
	    $i= sizeof($dir_arq) - 1; // pega o nome do arquivo, sem os diret�rios
	    $arquivo_miniatura= "..".$barra."..".$barra."galeria".$barra.$diretorio.$barra.$mini;
	    
	    // imagem de origem
	    if ($ext == "png")
	        $img_origem = imagecreatefrompng($imagem);
	    elseif ($ext == "jpg")
	        $img_origem = imagecreatefromjpeg($imagem);
	    elseif ($ext == "gif")
	        $img_origem = imagecreatefromgif($imagem);
	      
	    // obt�m as dimens�es da imagem original
	    $origem_x= ImagesX($img_origem);
	    $origem_y= ImagesY($img_origem);
	      
	    $x= $origem_x;
	    $y= $origem_y;
	      
	    // Aqui � feito um c�lculo para aproximar o tamanho da imagem ao valor passado em $aprox.
	    // N�o importa se a foto for grande ou pequena, o thumb de todas elas ser� mais ou menos do
	    // mesmo tamanho.
	    if ($x >= $y)
	    {
	        if ($x > $aprox)
	        {      
	            $x1= (int)($x * ($aprox/$x));    
	            $y1= (int)($y * ($aprox/$x));
	        }
	        // incluido o else abaixo. Caso a imagem seja menor do que
	        // deve ser aproximado, mant�m tamanho original para o thumb.
	        else
	        {
	            $x1= $x;
	            $y1= $y;
	        }
	    }
	    else
	    {
	        if ($y > $aprox)
	        {
	            $x1= (int)($x * ($aprox/$y));
	            $y1= (int)($y * ($aprox/$y));
	        }
	        // incluido o else abaixo. Caso a imagem seja menor do que
	        // deve ser aproximado, mant�m tamanho original para o thumb.
	        else
	        {
	            $x1= $x;
	            $y1= $y;
	        }
	    }
	    $x= $x1;
	    $y= $y1;
	
	    // cria a imagem do thumbnail
	    $img_final = ImageCreateTrueColor($x, $y);
	    ImageCopyResampled($img_final, $img_origem, 0, 0, 0, 0, $x+1, $y+1, $origem_x, $origem_y);

	    // o arquivo � gravado
	    if ($ext == "png")
	        imagepng($img_final, $arquivo_miniatura);
	    elseif ($ext == "jpg")
	        imagejpeg($img_final, $arquivo_miniatura);
	    elseif ($ext == "gif")
	        imagegif($img_final, $arquivo_miniatura);
	      
	    // a mem�ria usada para tudo isso � liberada.
	    ImageDestroy($img_origem);
	    ImageDestroy($img_final);
	    
	    return true;
	}
	
	function thumbMakerGaleria($imagem, $aprox, $mini,$diretorio)
	{
	    if (!file_exists($imagem))
	    {
	        
	    	echo "<center><h3>Imagem n�o encontrada.</h3></center>";
	        return false;
	    }
	
	    // verifica se est� executando sob windows ou unix-like, para a
	    // aplica��o do separador de diret�rios correto.
	    if (strtoupper(substr(PHP_OS, 0,3) == 'WIN'))
	       $barra= "\\";
	    else
	       $barra= "/";
	
	    // obt�m a extens�o pelo mime-type
	    $ext = $this->getExt($imagem);
	    if (!$ext)
	    {
	       echo "<center><h3>Tipo inv�lido</h3></center>";
	       return false;
	    }
	    // separa o nome do arquivo do(s) diret�rio(s)
	    $dir_arq= explode($barra, $imagem);
	      
	    // monta o nome do arquivo a ser gerado (thumbnail). O sizeof abaixo obt�m o n�mero de itens
	    // no array, dessa forma podemos pegar somente o nome do arquivo, n�o importando em que
	    // diret�rio est�.
	    $i= sizeof($dir_arq) - 1; // pega o nome do arquivo, sem os diret�rios
	    $arquivo_miniatura= "..".$barra."recursos".$barra."images".$barra.$diretorio.$barra.$mini;
	    
	    // imagem de origem
	    if ($ext == "png")
	        $img_origem = imagecreatefrompng($imagem);
	    elseif ($ext == "jpg")
	        $img_origem = imagecreatefromjpeg($imagem);
	    elseif ($ext == "gif")
	        $img_origem = imagecreatefromgif($imagem);
	      
	    // obt�m as dimens�es da imagem original
	    $origem_x= ImagesX($img_origem);
	    $origem_y= ImagesY($img_origem);
	      
	    $x= $origem_x;
	    $y= $origem_y;
	      
	    // Aqui � feito um c�lculo para aproximar o tamanho da imagem ao valor passado em $aprox.
	    // N�o importa se a foto for grande ou pequena, o thumb de todas elas ser� mais ou menos do
	    // mesmo tamanho.
	    if ($x >= $y)
	    {
	        if ($x > $aprox)
	        {      
	            $x1= (int)($x * ($aprox/$x));    
	            $y1= (int)($y * ($aprox/$x));
	        }
	        // incluido o else abaixo. Caso a imagem seja menor do que
	        // deve ser aproximado, mant�m tamanho original para o thumb.
	        else
	        {
	            $x1= $x;
	            $y1= $y;
	        }
	    }
	    else
	    {
	        if ($y > $aprox)
	        {
	            $x1= (int)($x * ($aprox/$y));
	            $y1= (int)($y * ($aprox/$y));
	        }
	        // incluido o else abaixo. Caso a imagem seja menor do que
	        // deve ser aproximado, mant�m tamanho original para o thumb.
	        else
	        {
	            $x1= $x;
	            $y1= $y;
	        }
	    }
	    $x= $x1;
	    $y= $y1;
	
	    // cria a imagem do thumbnail
	    $img_final = ImageCreateTrueColor($x, $y);
	    ImageCopyResampled($img_final, $img_origem, 0, 0, 0, 0, $x+1, $y+1, $origem_x, $origem_y);

	    // o arquivo � gravado
	    if ($ext == "png")
	        imagepng($img_final, $arquivo_miniatura);
	    elseif ($ext == "jpg")
	        imagejpeg($img_final, $arquivo_miniatura);
	    elseif ($ext == "gif")
	        imagegif($img_final, $arquivo_miniatura);
	      
	    // a mem�ria usada para tudo isso � liberada.
	    ImageDestroy($img_origem);
	    ImageDestroy($img_final);
	    
	    return true;
	}
	
	// getExt - Verifica o mime-type da imagem e retorna a extens�o do arquivo
	function getExt($imagem)
	{
	    // isso � para obter o mime-type da imagem.
	    $mime= getimagesize($imagem);
		
	    if ($mime[2] == 2)
	    {
	       $ext= "jpg";
	       return $ext;
	    }
	    else
	    if ($mime[2] == 3)
	    {
	       $ext= "png";
	       return $ext;
	    }
	    else
	    if ($mime[2] == 1)
	    {
	       $ext= "gif";
	       return $ext;
	    }
	    else
	       return false;
	}
	
	function thumbMakerAgenda($imagem, $aprox, $mini,$diretorio)
	{
	    if (!file_exists($imagem))
	    {
	        
	    	echo "<center><h3>Imagem n�o encontrada.</h3></center>";
	        return false;
	    }
	
	    // verifica se est� executando sob windows ou unix-like, para a
	    // aplica��o do separador de diret�rios correto.
	    if (strtoupper(substr(PHP_OS, 0,3) == 'WIN'))
	       $barra= "\\";
	    else
	       $barra= "/";
	
	    // obt�m a extens�o pelo mime-type
	    $ext = $this->getExt($imagem);
	    if (!$ext)
	    {
	       echo "<center><h3>Tipo inv�lido</h3></center>";
	       return false;
	    }
	    // separa o nome do arquivo do(s) diret�rio(s)
	    $dir_arq= explode($barra, $imagem);
	      
	    // monta o nome do arquivo a ser gerado (thumbnail). O sizeof abaixo obt�m o n�mero de itens
	    // no array, dessa forma podemos pegar somente o nome do arquivo, n�o importando em que
	    // diret�rio est�.
	    $i= sizeof($dir_arq) - 1; // pega o nome do arquivo, sem os diret�rios
	    $arquivo_miniatura= "..".$barra."..".$barra."recursos".$barra."images".$barra.$diretorio.$barra.$mini;
	    
	    // imagem de origem
	    if ($ext == "png")
	        $img_origem = imagecreatefrompng($imagem);
	    elseif ($ext == "jpg")
	        $img_origem = imagecreatefromjpeg($imagem);
	    elseif ($ext == "gif")
	        $img_origem = imagecreatefromgif($imagem);
	      
	    // obt�m as dimens�es da imagem original
	    $origem_x= ImagesX($img_origem);
	    $origem_y= ImagesY($img_origem);
	      
	    $x= $origem_x;
	    $y= $origem_y;
	      
	    // Aqui � feito um c�lculo para aproximar o tamanho da imagem ao valor passado em $aprox.
	    // N�o importa se a foto for grande ou pequena, o thumb de todas elas ser� mais ou menos do
	    // mesmo tamanho.
	    if ($x >= $y)
	    {
	        if ($x > $aprox)
	        {      
	            $x1= (int)($x * ($aprox/$x));    
	            $y1= (int)($y * ($aprox/$x));
	        }
	        // incluido o else abaixo. Caso a imagem seja menor do que
	        // deve ser aproximado, mant�m tamanho original para o thumb.
	        else
	        {
	            $x1= $x;
	            $y1= $y;
	        }
	    }
	    else
	    {
	        if ($y > $aprox)
	        {
	            $x1= (int)($x * ($aprox/$y));
	            $y1= (int)($y * ($aprox/$y));
	        }
	        // incluido o else abaixo. Caso a imagem seja menor do que
	        // deve ser aproximado, mant�m tamanho original para o thumb.
	        else
	        {
	            $x1= $x;
	            $y1= $y;
	        }
	    }
	    $x= $x1;
	    $y= $y1;
	
	    // cria a imagem do thumbnail
	    $img_final = ImageCreateTrueColor($x, $y);
	    ImageCopyResampled($img_final, $img_origem, 0, 0, 0, 0, $x+1, $y+1, $origem_x, $origem_y);

	    // o arquivo � gravado
	    if ($ext == "png")
	        imagepng($img_final, $arquivo_miniatura);
	    elseif ($ext == "jpg")
	        imagejpeg($img_final, $arquivo_miniatura);
	    elseif ($ext == "gif")
	        imagegif($img_final, $arquivo_miniatura);
	      
	    // a mem�ria usada para tudo isso � liberada.
	    ImageDestroy($img_origem);
	    ImageDestroy($img_final);
	    
	    return true;
	}
	
	function upload_musica($name,$type,$tmp_name,$size,$tamanho,$pasta) {	
		$erro = $config = array();
				
		// Tamanho m�ximo do arquivo (em bytes)
		$config["tamanho"] = $tamanho;		
				
		// Formul�rio postado... executa as a��es
		if($name)
		{  
		    // Verifica se o mime-type do arquivo � de musica
		    if(!eregi("^audio\/(mp3|mpeg|mpeg3|mpg)$", $type))
		    {
		        $_SESSION["formato"] = 1;		        
		    }		    
	        // Verifica tamanho do arquivo
	        if($size > $config["tamanho"])
	        {
	            $_SESSION["tamanho"] = 1;
	        }		        		       		    
		    
		    /// Imprime as mensagens de erro
		    if(isset($_SESSION["formato"]) OR isset($_SESSION["tamanho"]))
		    {		       
		    	$_SESSION["erro"] = 1;
		    	header("location: ../../admin/agenda.php?site=add");
		    }
		
		    // Veifica��o de dados OK, nenhum erro ocorrido, executa ent�o o upload...
		    else
		    {
		        // Pega extens�o do arquivo
		        preg_match("/\.(mp3|mpeg|mpeg3|mpg){1}$/i", $name, $ext);
		
		        // Gera um nome �nico para a musica
		        $musica_nome = $name;		        	 
		       		       	     
		        // Caminho de onde a musica ficar�
		       $imagem_dir = $pasta.$musica_nome;
		
		        // Faz o upload da musica
		        move_uploaded_file($tmp_name, $imagem_dir);		          				        		         		
		    }
		}
		return $musica_nome;
	}

function upload($name,$type,$tmp_name,$size,$tamanho,$largura,$altura,$pasta) {	
		$erro = $config = array();
				
		// Tamanho m�ximo do arquivo (em bytes)
		$config["tamanho"] = $tamanho;
		// Largura m�xima (pixels)
		$config["largura"] = $largura;
		// Altura m�xima (pixels)
		$config["altura"]  = $altura;
		
		// Formul�rio postado... executa as a��es
		if($name)
		{  
		    // Verifica se o mime-type do arquivo � de imagem
		    if(!eregi("^image|application\/(pjpeg|jpeg|png|gif|x-shockwave-flash)$", $type))
		    {
		        $erro[] = "<span class='imgERR'>Arquivo em formato inv�lido! A imagem deve ser jpg, jpeg, 
					bmp, gif , png ou swf. Envie outro arquivo</span>";
		    }
		    else
		    {
		        // Verifica tamanho do arquivo
		        if($size > $config["tamanho"])
		        {
		            $erro[] = "<span class='imgERR'>Arquivo em tamanho muito grande! 
				A imagem deve ser de no m�ximo " . $config["tamanho"] . " bytes. 
				Envie outro arquivo</span>";
		        }
		        
		        // Para verificar as dimens�es da imagem
		        $tamanhos = getimagesize($tmp_name);
		        
		        // Verifica largura
		        if($tamanhos[0] > $config["largura"])
		        {
		            $erro[] = "<span class='imgERR'>Largura da imagem n�o deve 
						ultrapassar " . $config["largura"] . " pixels</span>";
		        }
		
		        // Verifica altura
		        if($tamanhos[1] > $config["altura"])
		        {
		            $erro[] = "<span class='imgERR'>Altura da imagem n�o deve 
						ultrapassar " . $config["altura"] . " pixels</span>";
		        }
		    }
		    
		    /// Imprime as mensagens de erro
		    if(sizeof($erro))
		    {
		        foreach($erro as $err)
		        {
		            echo " - " . $err . "<br/>";
		        }
					
		        $ok = false;
		        //echo "<a href=\"javascript:history.back();\">Fazer Upload de Outra Imagem</a>";
		    }
		
		    // Veifica��o de dados OK, nenhum erro ocorrido, executa ent�o o upload...
		    else
		    {
		        // Pega extens�o do arquivo
		        preg_match("/\.(gif|bmp|png|jpg|jpeg|swf){1}$/i", $name, $ext);
		
		        // Gera um nome �nico para a imagem
		        $imagem_nome = date("Ymdi".rand()).$ext[0];
		        //$imagem_nome = $name;
		        //echo $imagem_nome;
		        //AdmBanners::addBanners($lado,$idcat,$numero,$imagem_nome,$tamanhos[0],$tamanhos[1],$url,$target,$tempo);	  
		       		       	     
		        // Caminho de onde a imagem ficar�
		       $imagem_dir = $pasta.$imagem_nome;
		
		        // Faz o upload da imagem
		        move_uploaded_file($tmp_name, $imagem_dir);
		        
		        //$dir1 = $pasta.$imagem_nome; 
		        
		        //$thumb = $pasta."_thumb";
		        //$this->thumbMaker($dir1,400,$id,$imagem_nome,"album");
    			//$this->thumbMaker($dir1,85,$imagem_nome,$thumb);    			
		        
		        $ok = true;
		            		  
		    }
		}
		return $imagem_nome;
	}
	
    function upload_imagem($name,$type,$tmp_name,$size,$tamanho,$largura,$altura,$pasta,$nome) {	
		$erro = $config = array();
				
		// Tamanho m�ximo do arquivo (em bytes)
		$config["tamanho"] = $tamanho;
		// Largura m�xima (pixels)
		$config["largura"] = $largura;
		// Altura m�xima (pixels)
		$config["altura"]  = $altura;
		
		// Formul�rio postado... executa as a��es
		if($name)
		{  
		    // Verifica se o mime-type do arquivo � de imagem
		    if(!eregi("^image|application\/(pjpeg|jpeg|png|gif|x-shockwave-flash)$", $type))
		    {
		        $erro[] = "<span class='imgERR'>Arquivo em formato inv�lido! A imagem deve ser jpg, jpeg, 
					bmp, gif , png ou swf. Envie outro arquivo</span>";
		    }
		    else
		    {
		        // Verifica tamanho do arquivo
		        if($size > $config["tamanho"])
		        {
		            $erro[] = "<span class='imgERR'>Arquivo em tamanho muito grande! 
				A imagem deve ser de no m�ximo " . $config["tamanho"] . " bytes. 
				Envie outro arquivo</span>";
		        }
		        
		        // Para verificar as dimens�es da imagem
		        $tamanhos = getimagesize($tmp_name);
		        
		        // Verifica largura
		        if($tamanhos[0] > $config["largura"])
		        {
		            $erro[] = "<span class='imgERR'>Largura da imagem n�o deve 
						ultrapassar " . $config["largura"] . " pixels</span>";
		        }
		
		        // Verifica altura
		        if($tamanhos[1] > $config["altura"])
		        {
		            $erro[] = "<span class='imgERR'>Altura da imagem n�o deve 
						ultrapassar " . $config["altura"] . " pixels</span>";
		        }
		    }
		    
		    /// Imprime as mensagens de erro
		    if(sizeof($erro))
		    {
		        foreach($erro as $err)
		        {
		            echo " - " . $err . "<br/>";
		        }
					
		        $ok = false;
		        //echo "<a href=\"javascript:history.back();\">Fazer Upload de Outra Imagem</a>";
		    }
		
		    // Veifica��o de dados OK, nenhum erro ocorrido, executa ent�o o upload...
		    else
		    {
		        // Pega extens�o do arquivo
		        preg_match("/\.(gif|bmp|png|jpg|jpeg|swf){1}$/i", $name, $ext);
		
		        // Gera um nome �nico para a imagem
		        $imagem_nome = $nome.$ext[0];
		        //$imagem_nome = $name;
		        		    	 		       		       	     
		        // Caminho de onde a imagem ficar�
		        $imagem_dir = "../../galeria/$pasta/".$imagem_nome;
		
		        // Faz o upload da imagem
		        move_uploaded_file($tmp_name, $imagem_dir);
		        
		        $ok = true;
		            		  
		    }
		}
		return $imagem_nome;
	}	
	
	function Boleto($nome,$email,$hospedagem,$adultos,$criancas1,$criancas2,$parcelas,$mensagem) {
		$body = '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
					<html>  
					<head>    
						<title>Placafor</title>  
					</head>  
					<body marginheight="0" marginwidth="0" bottommargin="0" leftmargin="0" rightmargin="0" topmargin="0" bgcolor="#f6f6f6" link="#0062a0" alink="#0062a0" vlink="#0062a0">  
						<table width="550" cellpadding="0" cellspacing="0" border="0" align="center" bgcolor="#ffffff">    
							<tbody> 
								<tr>   
									<td width="10" height="10"></td>   
									<td width="53" height="10"></td>   
									<td width="10" height="10"></td> 
								</tr>      
								<tr>        
									<td width="10"></td>
									<td width="530">          
										<table width="530" cellpadding="0" cellspacing="0" border="0">
											<tbody>
												<tr>                
													<td width="530">
														<a href="http://www.hypper.com.br/clientes/na/" target="_blank">
															<img src="http://www.hypper.com.br/clientes/na/recursos/imagens/top_news.jpg" border="0" title="Placafor" />
														</a>
													</td>
												</tr>
												<tr>
												<td>
													<table width="580" cellpadding="0" cellspacing="0" border="0">                    
														<tbody>                      
															<tr>                        
																<td width="40" height="20"></td>                        
																<td width="558" height="20"></td>                        
																<td width="40" height="20"></td>                      
															</tr>                      
															<tr>                        
																<td width="40"></td>                        
																<td width="458">                          																	                       
																	<font face="Tahoma" size="2" color="#333333">
																		<strong>Nome:</strong> '.$nome.'<br />
																	</font>
																	<font face="Tahoma" size="2" color="#333333">
																		<strong>E-mail:</strong> '.$email.'<br />
																	</font> 
																	<font face="Tahoma" size="2" color="#333333">
																		<strong>Hospedagem:</strong> '.$hospedagem.'<br />
																	</font>
																	<font face="Tahoma" size="2" color="#333333">
																		<strong>Adultos:</strong> '.$adultos.'<br />
																	</font> 
																	<font face="Tahoma" size="2" color="#333333">
																		<strong>Crian�as de 0-5:</strong> '.$criancas1.'<br />
																	</font>  
																	<font face="Tahoma" size="2" color="#333333">
																		<strong>Crian�as de 6-12:</strong> '.$criancas2.'<br />
																	</font> 
																	<font face="Tahoma" size="2" color="#333333">
																		<strong>Parcelas:</strong> '.$parcelas.'<br />
																	</font>                     																		
																	<br />                          
																	<img src="http://www.hypper.com.br/clientes/na/recursos/imagens/iconItemGreen.gif" /> 
																	<font face="Tahoma" size="2" color="#508d00">
																		<a href="'.$mensagem.'" target="_blank">
																			<strong>Clique aqui para ver seus boletos</strong>
																		</a>
																	</font>                        
																</td>                        
																<td width="40"></td>                      
															</tr>                      
															<tr>                        
																<td width="40" height="40"></td>                        
																<td width="558" height="40"></td>                        
																<td width="40" height="40"></td>                      
															</tr>                    
														</tbody>                  
													</table>                
												</td>              
											</tr>
											<tr>                
												<td width="530">
													<a href="http://www.hypper.com.br/clientes/na/" target="_blank">
														<img src="http://www.hypper.com.br/clientes/na/recursos/imagens/rod_news.jpg" border="0" title="Placafor" />
													</a>
												</td>
											</tr>            
										</tbody>          
									</table>	
								</td>        
								<td width="10"></td>      
							</tr>    
						</tbody>  
					</table>  
					</body>
					</html>';
		return $body;
	}
	
	function EnviaBoleto($contato,$email,$nome,$assunto,$hospedagem,$adultos,$criancas1,$criancas2,$parcelas,$mensagem) {		
		$headers = "MIME-Version: 1.0\n";
		$headers .= "Content-type: text/html; charset=iso-8859-1\n";
		$headers .= "From: Placafor <".$contato.">\n";
		$headers .= "Return-Path: ".$contato."\n";
		
		$assunto = $assunto;
	
		$mensagem = '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
					<html>  
					<head>    
						<title>Placafor</title>  
					</head>  
					<body marginheight="0" marginwidth="0" bottommargin="0" leftmargin="0" rightmargin="0" topmargin="0" bgcolor="#f6f6f6" link="#0062a0" alink="#0062a0" vlink="#0062a0">  
						<table width="550" cellpadding="0" cellspacing="0" border="0" align="center" bgcolor="#ffffff">    
							<tbody> 
								<tr>   
									<td width="10" height="10"></td>   
									<td width="53" height="10"></td>   
									<td width="10" height="10"></td> 
								</tr>      
								<tr>        
									<td width="10"></td>
									<td width="530">          
										<table width="530" cellpadding="0" cellspacing="0" border="0">
											<tbody>
												<tr>                
													<td width="530">
														<a href="http://www.hypper.com.br/clientes/na/" target="_blank">
															<img src="http://www.hypper.com.br/clientes/na/recursos/imagens/top_news.jpg" border="0" title="Placafor" />
														</a>
													</td>
												</tr>
												<tr>
												<td>
													<table width="580" cellpadding="0" cellspacing="0" border="0">                    
														<tbody>                      
															<tr>                        
																<td width="40" height="20"></td>                        
																<td width="558" height="20"></td>                        
																<td width="40" height="20"></td>                      
															</tr>                      
															<tr>                        
																<td width="40"></td>                        
																<td width="458">                          																	                       
																	<font face="Tahoma" size="2" color="#333333">
																		<strong>Nome:</strong> '.$nome.'<br />
																	</font>
																	<font face="Tahoma" size="2" color="#333333">
																		<strong>E-mail:</strong> '.$email.'<br />
																	</font> 
																	<font face="Tahoma" size="2" color="#333333">
																		<strong>Hospedagem:</strong> '.$hospedagem.'<br />
																	</font>
																	<font face="Tahoma" size="2" color="#333333">
																		<strong>Adultos:</strong> '.$adultos.'<br />
																	</font> 
																	<font face="Tahoma" size="2" color="#333333">
																		<strong>Crian�as de 0-5:</strong> '.$criancas1.'<br />
																	</font>  
																	<font face="Tahoma" size="2" color="#333333">
																		<strong>Crian�as de 6-12:</strong> '.$criancas2.'<br />
																	</font> 
																	<font face="Tahoma" size="2" color="#333333">
																		<strong>Parcelas:</strong> '.$parcelas.'<br />
																	</font>                     																		
																	<br />                          
																	<img src="http://www.hypper.com.br/clientes/na/recursos/imagens/iconItemGreen.gif" /> 
																	<font face="Tahoma" size="2" color="#508d00">
																		<a href="'.$mensagem.'" target="_blank">
																			<strong>Clique aqui para ver seus boletos</strong>
																		</a>
																	</font>                        
																</td>                        
																<td width="40"></td>                      
															</tr>                      
															<tr>                        
																<td width="40" height="40"></td>                        
																<td width="558" height="40"></td>                        
																<td width="40" height="40"></td>                      
															</tr>                    
														</tbody>                  
													</table>                
												</td>              
											</tr>
											<tr>                
												<td width="530">
													<a href="http://www.hypper.com.br/clientes/na/" target="_blank">
														<img src="http://www.hypper.com.br/clientes/na/recursos/imagens/rod_news.jpg" border="0" title="Placafor" />
													</a>
												</td>
											</tr>            
										</tbody>          
									</table>	
								</td>        
								<td width="10"></td>      
							</tr>    
						</tbody>  
					</table>  
					</body>
					</html>';		
		mail($email,$assunto,$mensagem,$headers);
	}
	
	function Contato($nome,$email,$mensagem,$resposta) {
		$body = '				
					<p><font face="Arial" color="#000000"><strong>Resposta de contato</strong> </font></p>					    						       
					        <p><strong><font face="Arial">Nome: </font></strong><font face="Arial">'.$nome.'</font><strong><font face="Arial"><br />
					        </font></strong></p>
					        <p><strong><font face="Arial">E-mail: </font></strong><font face="Arial">'.$email.'</font><strong><font face="Arial"><br />
					        </font></strong></p>					        
					        <p><strong><font face="Arial">Mensagem: </font></strong><font face="Arial" color="black">'.$mensagem.'</font><strong><font face="Arial"><br />
					        </font></strong></p>
					        <p><strong><font face="Arial">Resposta: </font></strong><font face="Arial" color="red">'.$resposta.'</font><strong><font face="Arial"><br />
					        </font></strong></p>						        						      					        					        					       
					        <p> </p>		
					';
		return $body;
	}
	
	function Orcamento($nome,$email,$mensagem,$resposta) {
		$body = '				
					<p><font face="Arial" color="#000000"><strong>Resposta de or�amento</strong> </font></p>					    						       
					        <p><strong><font face="Arial">Nome: </font></strong><font face="Arial">'.$nome.'</font><strong><font face="Arial"><br />
					        </font></strong></p>
					        <p><strong><font face="Arial">E-mail: </font></strong><font face="Arial">'.$email.'</font><strong><font face="Arial"><br />
					        </font></strong></p>					        
					        <p><strong><font face="Arial">Mensagem: </font></strong><font face="Arial" color="black">'.$mensagem.'</font><strong><font face="Arial"><br />
					        </font></strong></p>
					        <p><strong><font face="Arial">Resposta: </font></strong><font face="Arial" color="red">'.$resposta.'</font><strong><font face="Arial"><br />
					        </font></strong></p>						        						      					        					        					       
					        <p> </p>		
					';
		return $body;
	}
	
	function EnviaContato($contato,$email,$nome,$assunto,$mensagem,$resposta) {		
		$headers = "MIME-Version: 1.0\n";
		$headers .= "Content-type: text/html; charset=iso-8859-1\n";
		$headers .= "From: Placafor <".$contato.">\n";
		$headers .= "Return-Path: ".$contato."\n";
		
		$assunto = $assunto;
	
		$mensagem = '<html dir="ltr">
					    <head>
					    </head>
					    <body spellcheck="false">
					    	<p><font face="Arial" color="#000000"><strong>Resposta de contato</strong> </font></p>					    						       
					        <p><strong><font face="Arial">Nome: </font></strong><font face="Arial">'.$nome.'</font><strong><font face="Arial"><br />
					        </font></strong></p>
					        <p><strong><font face="Arial">E-mail: </font></strong><font face="Arial">'.$email.'</font><strong><font face="Arial"><br />
					        </font></strong></p>					        
					        <p><strong><font face="Arial">Mensagem: </font></strong><font face="Arial" color="black">'.$mensagem.'</font><strong><font face="Arial"><br />
					        </font></strong></p>
					        <p><strong><font face="Arial">Resposta: </font></strong><font face="Arial" color="red">'.$resposta.'</font><strong><font face="Arial"><br />
					        </font></strong></p>						        						      					        					        					       
					        <p> </p>
					    </body>
					</html>';
		
		mail($email,$assunto,$mensagem,$headers);
	}
			
	function AlertaContatos($contato,$email) {		
		$headers = "MIME-Version: 1.0\n";
		$headers .= "Content-type: text/html; charset=iso-8859-1\n";
		$headers .= "From:Painel Placafor <".$contato.">\n";
		$headers .= "Return-Path: ".$contato."\n";
		
		$assunto = "Alerta de contato";
	
		$mensagem = '<html dir="ltr">
					    <head>
					    </head>
					    <body spellcheck="false">
					    	<p><font face="Arial" color="#000000"><strong>Alerta de contato</strong> </font></p>					    						       
					        <p><a href="http://www.hypper.com.br/clientes/na/admin">Painel Administrativo Placafor</a></p><br />
					        </font></strong></p>					        					        						        						      					        					        					     
					        <p> </p>
					    </body>
					</html>';
		
		mail($email,$assunto,$mensagem,$headers);
	}	
	
	function AlertaOrcamento($contato,$email) {		
		$headers = "MIME-Version: 1.0\n";
		$headers .= "Content-type: text/html; charset=iso-8859-1\n";
		$headers .= "From:Painel Placafor <".$contato.">\n";
		$headers .= "Return-Path: ".$contato."\n";
		
		$assunto = "Alerta de contato";
	
		$mensagem = '<html dir="ltr">
					    <head>
					    </head>
					    <body spellcheck="false">
					    	<p><font face="Arial" color="#000000"><strong>Alerta de contato</strong> </font></p>					    						       
					        <p><a href="http://www.hypper.com.br/clientes/na/admin">Painel Administrativo Placafor</a></p><br />
					        </font></strong></p>					        					        						        						      					        					        					     
					        <p> </p>
					    </body>
					</html>';
		
		mail($email,$assunto,$mensagem,$headers);
	}	
	
	function EnvieEmail($email,$nome,$tipo) {							
		if($tipo == 1) {
			$tipoid = "noticias.php";
			$nome_tipo = "esta not�cia.";
			$nome_tipo2 = "uma de nossas not&iacute;cias,";
			$artigo = "a";
			$cat = "";
		}elseif($tipo == 2){
			$tipoid = "produtos.php";
			$nome_tipo = "este produto.";
			$nome_tipo2 = "um de nossos produtos,";
			$artigo = "o";
			$cat = "cat=".$_POST["cat"]."&";
		}		
		
		$assunto = utf8_decode($_POST["nome"])." indicou ".$nome_tipo;
		$msg = $nome_tipo2." clique no link abaixo para visualiz&aacute;-l".$artigo.".";									
		
		$mensagem = '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
					<html>  
					<head>    
						<title>Placafor</title>  
					</head>  
					<body marginheight="0" marginwidth="0" bottommargin="0" leftmargin="0" rightmargin="0" topmargin="0" bgcolor="#f6f6f6" link="#0062a0" alink="#0062a0" vlink="#0062a0">  
						<table width="550" cellpadding="0" cellspacing="0" border="0" align="center" bgcolor="#ffffff">    
							<tbody> 
								<tr>   
									<td width="10" height="10"></td>   
									<td width="53" height="10"></td>   
									<td width="10" height="10"></td> 
								</tr>      
								<tr>        
									<td width="10"></td>
									<td width="530">          
										<table width="530" cellpadding="0" cellspacing="0" border="0">
											<tbody>
												<tr>                
													<td width="530">
														<a href="http://www.hypper.com.br/clientes/placafor/" target="_blank">
															<img src="http://www.hypper.com.br/clientes/placafor/recursos/imagens/top_news.jpg" border="0" title="Placafor" />
														</a>
													</td>
												</tr>
												<tr>
												<td>
													<table width="580" cellpadding="0" cellspacing="0" border="0">                    
														<tbody>                      
															<tr>                        
																<td width="40" height="20"></td>                        
																<td width="558" height="20"></td>                        
																<td width="40" height="20"></td>                      
															</tr>                      
															<tr>                        
																<td width="40"></td>                        
																<td width="458">                          
																	<font face="Tahoma" size="3" color="#33333">
																		<strong>'.utf8_decode($nome).'</strong>,<br /><br />
																	</font>                          
																	<font face="Tahoma" size="2" color="#333333">
																		<strong>'.utf8_decode($_POST["nome"]).'</strong> lhe enviou '.$msg.'<br /><br />
																	</font>                          
																		<table width="90%" cellpadding="10" cellspacing="0" border="0" align="center">
																			<tbody>                              
																				<tr>                                
																					<td>
																						<font face="Tahoma" size="2" color="#333333">
																							<em>"'.utf8_decode($_POST["comentario"]).'"</em>
																						</font>
																					</td>                             
																				</tr>                            
																			</tbody>                          
																		</table>
																		<br />                          
																		<img src="http://www.hypper.com.br/clientes/placafor/recursos/imagens/iconItemGreen.gif" /> 
																		<font face="Tahoma" size="2" color="#508d00">
																			<a href="http://www.hypper.com.br/clientes/placafor/'.$tipoid.'?'.$cat.'id='.$_POST["id"].'" target="_blank">
																				<strong>Clique aqui para visualiz&aacute;-l'.$artigo.'</strong>
																			</a>
																		</font>                        
																</td>                        
																<td width="40"></td>                      
															</tr>                      
															<tr>                        
																<td width="40" height="40"></td>                        
																<td width="558" height="40"></td>                        
																<td width="40" height="40"></td>                      
															</tr>                    
														</tbody>                  
													</table>                
												</td>              
											</tr>
											<tr>                
												<td width="530">
													<a href="http://www.hypper.com.br/clientes/placafor/" target="_blank">
														<img src="http://www.hypper.com.br/clientes/placafor/recursos/imagens/rod_news.jpg" border="0" title="Placafor" />
													</a>
												</td>
											</tr>            
										</tbody>          
									</table>	
								</td>        
								<td width="10"></td>      
							</tr>    
						</tbody>  
					</table>  
					</body>
					</html>';		
		return $mensagem;		
	}
}
?>
