<?php
	require_once("constantes.php");
	require_once(ROOT."includes/loader.php");
	
	/* Verifica sessão do usuário */
	verificaSessao();
	
	$usuarioLogado = getUsuarioLogado();
	
	$categoriaDAO = new CategoriaDAO();
	$grupoDAO = new GrupoDAO();
	
	$select = "<select name=\"id_grupo_pai\">";
	$select .= "<option value=\"0\">CATEGORIA PRINCIPAL</option>\n";
	$arvore = "";
	
	foreach ($grupoDAO->listarGrupos() as $indice => $grupo) {
		$menu .= $grupo->getId_grupo()." -> ".$grupo->getDescricao();
		$select .= "<option value=\"".$grupo->getId_grupo()."\">".$grupo->getDescricao()."</option>\n";
	}
	$select .= "</select>";
	
	
	$tpl = new Template("paginas/base.html");
	$tpl->titulo = "MGV Eventos.com.br";
	$tpl->menu = "";
	$tpl->show();
?>

<form method="POST" action="class/Grupo/GrupoController.php">
	<?=$select?>
	<input type="text" name="descricao"/>
	<input type="submit" value="Enviar"/>
</form>

Mostrando estrutura de diretorios
<?php 

//echo "<ul id=\"primary-nav\">";
echo "<ul class=\"menu-hv\">";

foreach ($grupoDAO->listarGruposPai() as $indice => $grupo) {	
	$parent = $grupoDAO->temFilho($grupo->getId_grupo()) ? "class=\"menuparent\"" : "";
	echo "<li ".$parent."><a href=\"#\">".$grupo->getDescricao()."</a>";
	$grupoDAO->listarArvorePorGrupo($grupo->getId_grupo());
	echo "</li>";
}
echo "</ul>";

?>
