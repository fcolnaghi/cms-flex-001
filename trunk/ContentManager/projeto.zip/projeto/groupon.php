<?php

function getDeal($pagina) {
	$var = "\"price\">";
	$pos = strpos($pagina, $var); /* Acha onde esta localizado essa tag dentro do texto capturado */
	$dados = substr($pagina, $pos + strlen($var)); /*retorna parte do texto selecionado  echo $dados;*/
	$pos = strpos($dados, "</"); /* acha o final da string procurada */
	$preco = trim(ltrim(rtrim(strip_tags(substr($dados,0,$pos)))));
	
	$var = "\"jDealSoldAmount\">";
	$pos = strpos($pagina, $var); /* Acha onde esta localizado essa tag dentro do texto capturado */
	$dados = substr($pagina, $pos + strlen($var)); /*retorna parte do texto selecionado  echo $dados;*/
	$pos = strpos($dados, "</"); /* acha o final da string procurada */
	$vendidos = trim(ltrim(rtrim(strip_tags(substr($dados,0,$pos)))));
	
	$var = "<h1>";
	$pos = strpos($pagina, $var); /* Acha onde esta localizado essa tag dentro do texto capturado */
	$dados = substr($pagina, $pos + strlen($var)); /*retorna parte do texto selecionado  echo $dados;*/
	$pos = strpos($dados, "</h1>"); /* acha o final da string procurada */
	$oferta = trim(ltrim(rtrim(strip_tags(substr($dados,0,$pos)))));
	
	$var = "\"hoursLeft\">";
	$pos = strpos($pagina, $var); /* Acha onde esta localizado essa tag dentro do texto capturado */
	$dados = substr($pagina, $pos + strlen($var)); /*retorna parte do texto selecionado  echo $dados;*/
	$pos = strpos($dados, "</"); /* acha o final da string procurada */
	$timeleftHH = trim(ltrim(rtrim(strip_tags(substr($dados,0,$pos)))));
	
	$var = "\"minutesLeft\">";
	$pos = strpos($pagina, $var); /* Acha onde esta localizado essa tag dentro do texto capturado */
	$dados = substr($pagina, $pos + strlen($var)); /*retorna parte do texto selecionado  echo $dados;*/
	$pos = strpos($dados, "</"); /* acha o final da string procurada */
	$timeleftMM = trim(ltrim(rtrim(strip_tags(substr($dados,0,$pos)))));
	
	$var = "\"secondsLeft\">";
	$pos = strpos($pagina, $var); /* Acha onde esta localizado essa tag dentro do texto capturado */
	$dados = substr($pagina, $pos + strlen($var)); /*retorna parte do texto selecionado  echo $dados;*/
	$pos = strpos($dados, "</"); /* acha o final da string procurada */
	$timeleftSS = trim(ltrim(rtrim(strip_tags(substr($dados,0,$pos)))));
	
	$timeleft = $timeleftHH.":".$timeleftMM.":".$timeleftSS;
	
	echo $timeleft;
	echo "<br>";
	echo $oferta;
	echo "<br>";
	echo $vendidos;
	echo "<br>";
	echo $preco;
	echo "<br>";
}

$ch = curl_init ();
curl_setopt ( $ch, CURLOPT_URL, "http://www.groupon.com.br/ofertas/curitiba");
curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, 1 );
$response = curl_exec ( $ch );
curl_close( $ch );


getDeal($response);

?>